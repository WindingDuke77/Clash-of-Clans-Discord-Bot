module.exports = (Discord, client) => {
  console.log(`${client.user.username} is ready`);
};
